<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class purity extends Model
{
    //
    protected $fillable=['name','created_by'];
}
