<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class printStatus extends Model
{
    //
     //
     protected $fillable = [
         'name'
    ];
}
