<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BISNumber extends Model
{
    //
    protected $fillable = ['bis_number','created_by'];

}
