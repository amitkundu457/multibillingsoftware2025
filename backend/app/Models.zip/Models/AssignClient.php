<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssignClient extends Model
{
    //
    protected $fillable = ['client_id', 'distributor_id'];
}
