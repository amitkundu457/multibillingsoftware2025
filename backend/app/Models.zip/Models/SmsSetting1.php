<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmsSetting extends Model
{
   protected $fillable=[
'description',
'created_by',
'status',
   ];
}
