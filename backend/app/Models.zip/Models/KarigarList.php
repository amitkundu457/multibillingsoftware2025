<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KarigarList extends Model
{
    //
    protected $fillable = [
        'name',
        'created_By',
       
    ];
}
