<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tabs extends Model
{
    protected $fillable = ['image', 'title', 'descrition', 'icon'];
}
