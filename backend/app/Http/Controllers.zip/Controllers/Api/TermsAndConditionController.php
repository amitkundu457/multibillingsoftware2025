<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Termscondition;

use Illuminate\Http\Request;

class TermsAndConditionController extends Controller
{


    // Display a list of all records
    public function index()
    {
        $termsconditions = Termscondition::all();
        return response()->json($termsconditions);
    }

    // Store a new record in the database
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
        ]);

        $termscondition = Termscondition::create($request->all());
        return response()->json(['message' => 'Record created successfully!', 'data' => $termscondition], 201);
    }



    // Update an existing record
    public function update(Request $request, $id)
    {
        $termscondition = Termscondition::find($id);

        if (!$termscondition) {
            return response()->json(['message' => 'Record not found!'], 404);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
        ]);

        $termscondition->update($request->all());
        return response()->json(['message' => 'Record updated successfully!', 'data' => $termscondition]);
    }

    // Delete a record
    public function destroy($id)
    {
        $termscondition = Termscondition::find($id);

        if (!$termscondition) {
            return response()->json(['message' => 'Record not found!'], 404);
        }

        $termscondition->delete();
        return response()->json(['message' => 'Record deleted successfully!']);
    }
}


