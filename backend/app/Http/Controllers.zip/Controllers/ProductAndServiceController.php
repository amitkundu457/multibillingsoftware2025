<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductService;

class ProductAndServiceController extends Controller
{
   
    
}
