<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SmsSettingController extends Controller
{
    //this controller not used right now please avoid this if you using this controller 
}
